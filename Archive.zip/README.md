# ZendeskTheme

Theme Kartable pour le support Zendesk.

## Requirements

- Rake

`$ gem install rake`

- Zendesk App Tool

`$ gem install zendesk_apps_tools`


## Start
`$ zat theme preview`   And login with a kartable zendesk account.

Visit https://support.kartable.fr/hc/admin/local_preview/start to view your changes.

 Allow mixed-contents into browser :
- Firefox : Click on lock into address bar
- Chrome : Click on shield into address bar

## Export
Zip folder and import it from Zendesk backoffice.
